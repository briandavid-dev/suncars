<section class="banner-wrap">
    <div class="banner">
        
        <div class="forcefullwidth_wrapper_tp_banner" id="rev_slider_forcefullwidth" style="position:relative;width:100%;height:auto;margin-top:0px;margin-bottom:0px"><div class="rev_slider_wrapper tp-mouseover" style="margin-top: 0px; margin-bottom: 0px; position: absolute; overflow: visible; width: 1349px; left: 0px; height: 645px;">            
            <!-- START REVOLUTION SLIDER 5.0 auto mode -->
            <div id="rev_slider" class="rev_slider revslider-initialised tp-simpleresponsive" data-version="5.0" style="max-height: 645px; margin-top: 0px; margin-bottom: 0px; height: 645px;" data-slideactive="rs-743639">
                <ul class="tp-revslider-mainul" style="visibility: visible; display: block; overflow: hidden; width: 100%; height: 100%; max-height: none;">    
                    <!-- SLIDE  -->
                    <li data-transition="fade" class="tp-revslider-slidesli" style="width: 100%; height: 100%; overflow: hidden; z-index: 18; visibility: hidden; opacity: 0; background-color: rgba(255, 255, 255, 0);">
                        
                        <!-- MAIN IMAGE -->
                        <div class="slotholder" style="position: absolute; top: 0px; left: 0px; z-index: 0; width: 100%; height: 100%; visibility: inherit; opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);"><!--Runtime Modification - Img tag is Still Available for SEO Goals in Source - <img src="images/slide-show1.jpg" alt="" class="defaultimg">--><div class="tp-bgimg defaultimg " data-bgcolor="undefined" style="background-repeat: no-repeat; background-size: cover; background-position: center center; width: 100%; height: 100%; opacity: 1; background-image: url(&quot;themes/automovile/images/slide-show1.jpg&quot;); visibility: inherit; z-index: 20;" src="themes/automovile/images/slide-show1.jpg"></div></div>                           
                        <!-- LAYERS -->
                        <div class="tp-parallax-wrap" style="position: absolute; display: block; visibility: hidden; left: 90px; top: 214px; z-index: 1;"><div class="tp-loop-wrap" style="position:absolute;display:block;;"><div class="tp-mask-wrap" style="position: absolute; display: block; overflow: visible;"><div class="tp-caption mediumlarge_light_white_center domainate start" data-x="0" data-hoffset="0" data-y="214" data-transform_in="z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;s:1000;e:Power2.easeOut;" data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" data-start="1000" data-splitin="none" data-splitout="none" data-speed="1000" data-endspeed="300" id="layer-496315732" style="visibility: inherit; text-align: inherit; line-height: 40px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: -6px; font-weight: 800; font-size: 72px; white-space: nowrap; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px; transition: none;">DOMINATE </div></div></div></div>
                        
                        <!-- LAYER NR. 1 -->
                        <div class="tp-parallax-wrap" style="position: absolute; display: block; visibility: hidden; left: 90px; top: 282px; z-index: 6;"><div class="tp-loop-wrap" style="position:absolute;display:block;;"><div class="tp-mask-wrap" style="position: absolute; display: block; overflow: visible;"><div class="tp-caption internet" data-x="0" data-y="282" data-speed="500" data-start="800" data-transform_in="z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;s:1000;e:Power2.easeOut;" data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" data-splitin="none" data-splitout="none" style="z-index: 6; letter-spacing: -3px; visibility: inherit; text-align: inherit; line-height: 24px; border-width: 0px; margin: 0px; padding: 0px 0px 55px; font-weight: 400; font-size: 55px; white-space: nowrap; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px; transition: none;" id="layer-914231992">THE INTERNET </div></div></div></div>

                        <!-- LAYER NR. 2 -->
                        <div class="tp-parallax-wrap" style="position: absolute; display: block; visibility: hidden; left: 90px; top: 369px; z-index: 6;"><div class="tp-loop-wrap" style="position:absolute;display:block;;"><div class="tp-mask-wrap" style="position: absolute; display: block; overflow: visible;"><div class="tp-caption attract " data-x="0" data-y="369" data-speed="500" data-start="1700" data-transform_in="y:-50px;opacity:0;s:1500;e:Power3.easeOut;" data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" data-splitin="none" data-splitout="none" style="z-index: 6; visibility: inherit; text-align: inherit; line-height: 24px; border-width: 2px 0px 0px; margin: 0px; padding: 16px 0px 0px; letter-spacing: -2px; font-weight: 400; font-size: 30px; white-space: nowrap; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px; transition: none;" id="layer-395194191">Attract, Engage, &amp; Convert </div></div></div></div>

                        <!-- LAYER NR. 3 -->
                        <div class="tp-parallax-wrap" style="position: absolute; display: block; visibility: hidden; left: 190px; top: 425px; z-index: 6;"><div class="tp-loop-wrap" style="position:absolute;display:block;;"><div class="tp-mask-wrap" style="position: absolute; display: block; overflow: visible;"><div class="tp-caption more " data-x="100" data-y="425" data-speed="800" data-start="1900" data-transform_in="x:-50px;opacity:0;s:2000;e:Power3.easeOut;" data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" data-splitin="none" data-splitout="none" style="z-index: 6; visibility: inherit; text-align: inherit; line-height: 24px; border-width: 0px; margin: 0px; padding: 0px 5px; letter-spacing: 0px; font-weight: 500; font-size: 70px; white-space: nowrap; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px; transition: none;" id="layer-273431948">more </div></div></div></div>

                        <!-- LAYER NR. 4 -->
                        <div class="tp-parallax-wrap" style="position: absolute; display: block; visibility: hidden; left: 90px; top: 476px; z-index: 6;"><div class="tp-loop-wrap" style="position:absolute;display:block;;"><div class="tp-mask-wrap" style="position: absolute; display: block; overflow: visible;"><div class="tp-caption qualified" data-x="0" data-y="476" data-speed="800" data-start="2600" data-transform_in="y:50px;opacity:0;s:1500;e:Power3.easeOut;" data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" data-splitin="none" data-splitout="none" style="z-index: 6; visibility: inherit; text-align: inherit; line-height: 24px; border-width: 0px 0px 2px; margin: 0px; padding: 0px 0px 16px; letter-spacing: -2px; font-weight: 400; font-size: 30px; white-space: nowrap; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px; transition: none;" id="layer-618754594">qualified vehicle shoppers </div></div></div></div>

                        
                    </li>
                    
                    <!-- SLIDE  -->
                    <li data-transition="fade" class="tp-revslider-slidesli active-revslide" style="width: 100%; height: 100%; overflow: hidden; z-index: 20; visibility: inherit; opacity: 1; background-color: rgba(255, 255, 255, 0);">
                        
                        <!-- MAIN IMAGE -->
                        <div class="slotholder" style="position: absolute; top: 0px; left: 0px; z-index: 0; width: 100%; height: 100%; visibility: inherit; opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);"><!--Runtime Modification - Img tag is Still Available for SEO Goals in Source - <img src="images/slide-show2.jpg" alt="" class="defaultimg">--><div class="tp-bgimg defaultimg " data-bgcolor="undefined" style="background-repeat: no-repeat; background-size: cover; background-position: center center; width: 100%; height: 100%; opacity: 1; background-image: url(&quot;themes/automovile/images/slide-show2.jpg&quot;); visibility: inherit; z-index: 20;" src="themes/automovile/images/slide-show2.jpg"></div></div>                           

                        <!-- LAYERS -->
                        <div class="tp-parallax-wrap" style="position: absolute; display: block; visibility: visible; left: 633px; top: 160px; z-index: 1;"><div class="tp-loop-wrap" style="position:absolute;display:block;;"><div class="tp-mask-wrap" style="position: absolute; display: block; overflow: visible;"><div class="tp-caption mediumlarge_light_white_center invest" data-x="543" data-y="160" data-speed="500" data-start="300" data-transform_in="x:right;s:2000;e:Power4.easeInOut;" data-transform_out="s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" data-splitin="none" data-splitout="none" id="layer-935794521" style="visibility: inherit; text-align: inherit; line-height: 40px; border-width: 0px; margin: 0px; padding: 5px; letter-spacing: -3px; font-weight: 300; font-size: 48px; white-space: nowrap; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px; transition: none;">Time to invest in a website built to </div></div></div></div>
                        
                        <!-- LAYER NR. 1 -->
                        <div class="tp-parallax-wrap" style="position: absolute; display: block; visibility: visible; left: 570px; top: 230px; z-index: 6;"><div class="tp-loop-wrap" style="position:absolute;display:block;;"><div class="tp-mask-wrap" style="position: absolute; display: block; overflow: visible;"><div class="tp-caption move mediumlarge_light_white_center" data-x="480" data-y="230" data-speed="500" data-start="800" data-transform_in="x:right;s:2000;e:Power4.easeInOut;" data-transform_out="s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" data-splitin="none" data-splitout="none" style="z-index: 6; letter-spacing: -3px; visibility: inherit; text-align: inherit; line-height: 40px; border-width: 0px; margin: 0px; padding: 0px; font-weight: 800; font-size: 46px; white-space: nowrap; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px; transition: none;" id="layer-759947113">MOVE </div></div></div></div>

                        <!-- LAYER NR. 2 -->
                        <div class="tp-parallax-wrap" style="position: absolute; display: block; visibility: visible; left: 705px; top: 230px; z-index: 6;"><div class="tp-loop-wrap" style="position:absolute;display:block;;"><div class="tp-mask-wrap" style="position: absolute; display: block; overflow: visible;"><div class="tp-caption light_brown mediumlarge_light_white_center sfl" data-x="615" data-y="230" data-speed="500" data-start="1200" data-transform_in="x:right;s:2000;e:Power4.easeInOut;" data-transform_out="s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" data-splitin="none" data-splitout="none" style="z-index: 6; visibility: inherit; text-align: inherit; line-height: 40px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: -6px; font-weight: 800; font-size: 46px; white-space: nowrap; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px; transition: none;" id="layer-815843461">YOUR </div></div></div></div>

                        <!-- LAYER NR. 3 -->
                        <div class="tp-parallax-wrap" style="position: absolute; display: block; visibility: visible; left: 825px; top: 230px; z-index: 6;"><div class="tp-loop-wrap" style="position:absolute;display:block;;"><div class="tp-mask-wrap" style="position: absolute; display: block; overflow: visible;"><div class="tp-caption dark_brown mediumlarge_light_white_center " data-x="735" data-y="230" data-speed="800" data-start="1900" data-transform_in="x:right;s:2000;e:Power4.easeInOut;" data-transform_out="s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" data-splitin="none" data-splitout="none" style="z-index: 6; visibility: inherit; text-align: inherit; line-height: 40px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: -6px; font-weight: 800; font-size: 46px; white-space: nowrap; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px; transition: none;" id="layer-12194800">INVENTORY </div></div></div></div>

                        <!-- LAYER NR. 4 -->
                        <div class="tp-parallax-wrap" style="position: absolute; display: block; visibility: visible; left: 1050px; top: 230px; z-index: 6;"><div class="tp-loop-wrap" style="position:absolute;display:block;;"><div class="tp-mask-wrap" style="position: absolute; display: block; overflow: visible;"><div class="tp-caption faster mediumlarge_light_white_center rs-toggle-content-active" data-x="960" data-y="230" data-speed="800" data-start="2600" data-transform_in="x:right;s:2000;e:Power4.easeInOut;" data-transform_out="s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" data-splitin="none" data-splitout="none" style="z-index: 6; visibility: inherit; text-align: inherit; line-height: 40px; border-width: 0px; margin: 0px; padding: 0px 10px 0px 0px; letter-spacing: -2px; font-weight: 300; font-size: 65px; white-space: nowrap; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px; transition: none;" id="layer-271946182">FASTER </div></div></div></div>

                        <!-- LAYER NR. 5 -->
                        <div class="tp-parallax-wrap" style="position: absolute; display: block; visibility: visible; left: 548px; top: 273px; z-index: 6;"><div class="tp-loop-wrap" style="position:absolute;display:block;;"><div class="tp-mask-wrap" style="position: absolute; display: block; overflow: visible;"><div class="tp-caption brown_line" data-x="458" data-y="273" data-speed="800" data-start="2600" data-transform_in="x:right;s:2000;e:Power4.easeInOut;" data-transform_out="s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" data-splitin="none" data-splitout="none" style="z-index: 6; visibility: inherit; text-align: inherit; line-height: 0px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 14px; white-space: nowrap; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px; transition: none;" id="layer-244870421"><img src="./themes/automovile/index_files/brown_line.jpg" alt="underline" style="width: 512px; height: 2px;"> </div></div></div></div>                    
                    </li>

                    <!-- SLIDE  -->
                    <li data-transition="fade" class="tp-revslider-slidesli" style="width: 100%; height: 100%; overflow: hidden; z-index: 18; visibility: hidden; opacity: 0; background-color: rgba(255, 255, 255, 0);">
                        
                        <!-- MAIN IMAGE -->
                        <div class="slotholder" style="position: absolute; top: 0px; left: 0px; z-index: 0; width: 100%; height: 100%; visibility: inherit; opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);"><!--Runtime Modification - Img tag is Still Available for SEO Goals in Source - <img src="images/slide-show3.jpg" alt="" class="defaultimg">--><div class="tp-bgimg defaultimg " data-bgcolor="undefined" style="background-repeat: no-repeat; background-size: cover; background-position: center center; width: 100%; height: 100%; opacity: 1; background-image: url(&quot;themes/automovile/images/slide-show3.jpg&quot;); visibility: inherit; z-index: 20;" src="themes/automovile/images/slide-show3.jpg"></div></div>                           

                        <!-- LAYERS -->
                        <div class="tp-parallax-wrap" style="position: absolute; display: block; visibility: hidden; left: 130px; top: 510px; z-index: 1;"><div class="tp-loop-wrap" style="position:absolute;display:block;;"><div class="tp-mask-wrap" style="position: absolute; display: block; overflow: visible;"><div class="tp-caption customin customout start green" data-x="40" data-hoffset="0" data-y="510" data-transform_in="y:top;s:2000;e:Power4.easeInOut;" data-transform_out="s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" data-speed="1000" data-start="500" data-endspeed="300" id="layer-203430206" style="visibility: inherit; text-align: inherit; line-height: 24px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: -4px; font-weight: 400; font-size: 48px; white-space: nowrap; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px; transition: none;">Wow Factor?</div></div></div></div>
                        
                        <!-- LAYER NR. 1 -->
                        <div class="tp-parallax-wrap" style="position: absolute; display: block; visibility: hidden; left: 130px; top: 560px; z-index: 6;"><div class="tp-loop-wrap" style="position:absolute;display:block;;"><div class="tp-mask-wrap" style="position: absolute; display: block; overflow: visible;"><div class="tp-caption big_white fade" data-x="40" data-y="560" data-speed="500" data-start="800" data-transform_in="y:bottom;s:2000;e:Power4.easeInOut;" data-transform_out="s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" style="z-index: 6; visibility: inherit; text-align: inherit; line-height: 24px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: -6px; font-weight: 800; font-size: 72px; white-space: nowrap; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px; transition: none;" id="layer-237848316">STANDARD. </div></div></div></div>                    
                    </li>

                    <!-- SLIDE  -->
                    <li data-transition="fade" class="tp-revslider-slidesli" style="width: 100%; height: 100%; overflow: hidden; z-index: 18; visibility: hidden; opacity: 0; background-color: rgba(255, 255, 255, 0);">
                        <!-- MAIN IMAGE --> 
                        <div class="slotholder" style="position: absolute; top: 0px; left: 0px; z-index: 0; width: 100%; height: 100%; visibility: inherit; opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);"><!--Runtime Modification - Img tag is Still Available for SEO Goals in Source - <img src="images/slide-show4.jpg" alt="" class="defaultimg">--><div class="tp-bgimg defaultimg " data-bgcolor="undefined" style="background-repeat: no-repeat; background-size: cover; background-position: center center; width: 100%; height: 100%; opacity: 1; background-image: url(&quot;themes/automovile/images/slide-show4.jpg&quot;); visibility: inherit; z-index: 20;" src="themes/automovile/images/slide-show4.jpg"></div></div> 
                        
                        <!-- LAYERS -->
                        <div class="tp-parallax-wrap" style="position: absolute; display: block; visibility: hidden; left: 90px; top: 235px; z-index: 1;"><div class="tp-loop-wrap" style="position:absolute;display:block;;"><div class="tp-mask-wrap" style="position: absolute; display: block; overflow: visible;"><div class="tp-caption customin customout start big_white" data-x="0" data-hoffset="0" data-y="235" data-transform_in="x:-50px;opacity:0;s:2000;e:Power3.easeOut;" data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" data-speed="1000" data-start="500" data-easing="Back.easeInOut" data-endspeed="300" id="layer-596424393" style="visibility: inherit; text-align: inherit; line-height: 24px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: -6px; font-weight: 800; font-size: 72px; white-space: nowrap; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px; transition: none;">UNLOCK</div></div></div></div>
                        
                        <!-- LAYER NR. 1 -->
                        <div class="tp-parallax-wrap" style="position: absolute; display: block; visibility: hidden; left: 390px; top: 235px; z-index: 6;"><div class="tp-loop-wrap" style="position:absolute;display:block;;"><div class="tp-mask-wrap" style="position: absolute; display: block; overflow: visible;"><div class="tp-caption thin_red fade" data-x="300" data-y="235" data-speed="500" data-start="800" data-transform_in="x:-50px;opacity:0;s:2000;e:Power3.easeOut;" data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" style="z-index: 6; visibility: inherit; text-align: inherit; line-height: 24px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: -6px; font-weight: 200; font-size: 75px; white-space: nowrap; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px; transition: none;" id="layer-971597837">THE POTENTIAL</div></div></div></div>
                        
                        <!-- LAYER NR. 2 -->
                        <div class="tp-parallax-wrap" style="position: absolute; display: block; visibility: hidden; left: 90px; top: 510px; z-index: 6;"><div class="tp-loop-wrap" style="position:absolute;display:block;;"><div class="tp-mask-wrap" style="position: absolute; display: block; overflow: visible;"><div class="tp-caption thin_white skewfromright" data-x="0" data-y="510" data-speed="500" data-start="800" data-transform_in="y:50px;opacity:0;s:1500;e:Power3.easeOut;" data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" style="z-index: 6; visibility: inherit; text-align: inherit; line-height: 24px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: -6px; font-weight: 200; font-size: 72px; white-space: nowrap; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px; transition: none;" id="layer-565866374">business from your</div></div></div></div>
                        
                        <!-- LAYER NR. 3 -->
                        <div class="tp-parallax-wrap" style="position: absolute; display: block; visibility: hidden; left: 490px; top: 570px; z-index: 6;"><div class="tp-loop-wrap" style="position:absolute;display:block;;"><div class="tp-mask-wrap" style="position: absolute; display: block; overflow: visible;"><div class="tp-caption cursive skewfromright" data-x="400" data-y="570" data-speed="500" data-start="800" data-transform_in="y:50px;opacity:0;s:1500;e:Power3.easeOut;" data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" style="z-index: 6; visibility: inherit; text-align: inherit; line-height: 24px; border-width: 0px; margin: 0px; padding: 0px 20px 0px 0px; letter-spacing: -6px; font-weight: 400; font-size: 122px; white-space: nowrap; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px; transition: none;" id="layer-181589786">website</div></div></div></div>
                    </li>

                    <!-- SLIDE  -->
                    <li data-transition="fade" class="tp-revslider-slidesli" style="width: 100%; height: 100%; overflow: hidden; z-index: 18; visibility: hidden; opacity: 0; background-color: rgba(255, 255, 255, 0);"> 
                        <!-- MAIN IMAGE --> 
                        <div class="slotholder" style="position: absolute; top: 0px; left: 0px; z-index: 0; width: 100%; height: 100%; visibility: inherit; opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);"><!--Runtime Modification - Img tag is Still Available for SEO Goals in Source - <img src="images/slide-show5.jpg" alt="" class="defaultimg">--><div class="tp-bgimg defaultimg " data-bgcolor="undefined" style="background-repeat: no-repeat; background-size: cover; background-position: center center; width: 100%; height: 100%; opacity: 1; background-image: url(&quot;themes/automovile/images/slide-show5.jpg&quot;); visibility: inherit; z-index: 20;" src="themes/automovile/images/slide-show5.jpg"></div></div> 
                        
                        <!-- LAYERS -->
                        <div class="tp-parallax-wrap" style="position: absolute; display: block; visibility: hidden; left: 90px; top: 199px; z-index: 1;"><div class="tp-loop-wrap" style="position:absolute;display:block;;"><div class="tp-mask-wrap" style="position: absolute; display: block; overflow: visible;"><div class="tp-caption mediumlarge_light_white_center domainate customin customout start" data-x="0" data-hoffset="0" data-y="199" data-transform_in="z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;s:1000;e:Power2.easeOut;" data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" data-speed="1000" data-start="500" data-easing="Back.easeInOut" data-endspeed="300" id="layer-811621746" style="visibility: inherit; text-align: inherit; line-height: 40px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: -6px; font-weight: 800; font-size: 72px; white-space: nowrap; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px; transition: none;">REALITY </div></div></div></div>
                        
                        <!-- LAYER NR. 1 -->
                        <div class="tp-parallax-wrap" style="position: absolute; display: block; visibility: hidden; left: 360px; top: 210px; z-index: 6;"><div class="tp-loop-wrap" style="position:absolute;display:block;;"><div class="tp-mask-wrap" style="position: absolute; display: block; overflow: visible;"><div class="tp-caption thin_dark_blue fade" data-x="270" data-y="210" data-speed="500" data-start="800" data-transform_in="z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;s:1000;e:Power2.easeOut;" data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" style="z-index: 6; letter-spacing: 0px; visibility: inherit; text-align: inherit; line-height: 24px; border-width: 0px; margin: 0px; padding: 0px; font-weight: 200; font-size: 75px; white-space: nowrap; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px; transition: none;" id="layer-34751916">IS JUST</div></div></div></div>
                        
                        <!-- LAYER NR. 2 -->
                        <div class="tp-parallax-wrap" style="position: absolute; display: block; visibility: hidden; left: 95px; top: 270px; z-index: 6;"><div class="tp-loop-wrap" style="position:absolute;display:block;;"><div class="tp-mask-wrap" style="position: absolute; display: block; overflow: visible;"><div class="tp-caption thinner_white sfl" data-x="05" data-y="270" data-speed="500" data-start="1200" data-transform_in="z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;s:1000;e:Power2.easeOut;" data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" style="z-index: 6; visibility: inherit; text-align: inherit; line-height: 24px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: -5px; font-weight: 200; font-size: 65px; white-space: nowrap; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px; transition: none;" id="layer-11405267">your perception</div></div></div></div>
                    </li>
                </ul>               
            <div class="tp-loader spinner0" style="display: none;"><div class="dot1"></div><div class="dot2"></div><div class="bounce1"></div><div class="bounce2"></div><div class="bounce3"></div></div><div class="tp-bannertimer" style="width: 29.4556%; transform: translate3d(0px, 0px, 0px); visibility: visible;"></div><div class="tp-leftarrow tparrows" style="top: 50%; transform: matrix(1, 0, 0, 1, 20, -20); left: 0px; visibility: inherit; opacity: 1;"></div><div class="tp-rightarrow tparrows" style="top: 50%; transform: matrix(1, 0, 0, 1, -60, -20); left: 100%; visibility: inherit; opacity: 1;"></div></div><!-- END REVOLUTION SLIDER -->
        </div><div class="tp-fullwidth-forcer" style="width: 100%; height: 645px;"></div></div><!-- END REVOLUTION SLIDER WRAPPER -->    

        <script>
        /******************************************
        -   PREPARE PLACEHOLDER FOR SLIDER  -
        ******************************************/
        
        var revapi;
        jQuery(document).ready(function() {     
            revapi = jQuery("#rev_slider").revolution({
                sliderType:"standard",
                sliderLayout:"fullwidth",
                delay:9000,
                navigation: {
                    arrows:{enable:true}                
                },          
                gridwidth:1170,
                gridheight:645      
            });     
        }); /*ready*/
        </script>       
        
        <!-- END REVOLUTION SLIDER --> 
        
        <!-- Content End --> 
        
    </div>
</section>



<section class="message-wrap">
    <div class="container">
        <div class="row">
            <h2 class="col-lg-9 col-md-8 col-sm-12 col-xs-12 xs-padding-left-15">aaa Discover a website for car dealers that converts visitors to <span class="alternate-font">customers</span></h2>
            <div class="col-lg-3 col-md-4 col-sm-12 col-xs-12 xs-padding-right-15"> <a href="https://demo.themesuite.com/automotive/#" class="default-btn pull-right action_button lg-button">Schedule a Test Drive</a> </div>
        </div>
    </div>
    <div class="message-shadow"></div>
</section>
<!--message-wrap ends-->
<section class="content">
    <div class="container">
        <div class="inner-page homepage margin-bottom-none">
            <section class="car-block-wrap padding-bottom-40">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 margin-bottom-none">
                            <div class="flip margin-bottom-30">
                                <div class="card">
                                    <div class="face front"><img class="img-responsive" src="./themes/automovile/index_files/car1.jpg" alt=""></div>
                                    <div class="face back">
                                        <div class="hover_title">Race Ready</div>
                                        <a href="https://demo.themesuite.com/automotive/inventory-listing.html"><i class="fa fa-link button_icon"></i></a> <a href="https://demo.themesuite.com/automotive/images/car1-lrg.jpg" class="fancybox"><i class="fa fa-arrows-alt button_icon"></i></a> </div>
                                </div>
                            </div>
                            <h4><a href="https://demo.themesuite.com/automotive/#">FACTORY READY FOR TRACK DAY</a></h4>
                            <p class="margin-bottom-none">Sea veniam lucilius neglegentur ad, an per sumo volum
                                voluptatibus. Qui cu everti repudiare. Eam ut cibo nobis 
                                aperiam, elit qualisque at cum. Possit antiopam id est. 
                                Illud delicata ea mel, sed novum mucius id. Nullam qua.</p>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 margin-bottom-none">
                            <div class="flip horizontal margin-bottom-30">
                                <div class="card">
                                    <div class="face front"><img class="img-responsive" src="./themes/automovile/index_files/car2.jpg" alt=""></div>
                                    <div class="face back">
                                        <div class="hover_title">Family Oriented</div>
                                        <a href="https://demo.themesuite.com/automotive/inventory-listing.html"><i class="fa fa-link button_icon"></i></a> <a href="https://demo.themesuite.com/automotive/images/car2-lrg.jpg" class="fancybox"><i class="fa fa-arrows-alt button_icon"></i></a> </div>
                                </div>
                            </div>
                            <h4><a href="https://demo.themesuite.com/automotive/#">A SPORT UTILITY FOR THE FAMILY</a></h4>
                            <p class="margin-bottom-none">Cum ut tractatos imperdiet, no tamquam facilisi qui. 
                                Eum tibique consectetuer in, an legimus referrentur vis, 
                                vocent deseruisse ex mel. Sed te idque graecis. Vel ne 
                                libris dolores, in mel graece dolorum.</p>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 margin-bottom-none">
                            <div class="flip margin-bottom-30">
                                <div class="card">
                                    <div class="face front"><img class="img-responsive" src="./themes/automovile/index_files/car3.jpg" alt=""></div>
                                    <div class="face back">
                                        <div class="hover_title">World Class</div>
                                        <a href="https://demo.themesuite.com/automotive/inventory-listing.html"><i class="fa fa-link button_icon"></i></a> <a href="https://demo.themesuite.com/automotive/images/car3-lrg.jpg" class="fancybox"><i class="fa fa-arrows-alt button_icon"></i></a> </div>
                                </div>
                            </div>
                            <h4><a href="https://demo.themesuite.com/automotive/#">MAKE AN EXECUTIVE STATEMENT</a></h4>
                            <p class="margin-bottom-none">Te inermis cotidieque cum, sed ea utroque atomorum 
                                sadipscing. Qui id oratio everti scaevola, vim ea augue 
                                ponderum vituperatoribus, quo adhuc abhorreant 
                                omittantur ad. No his fierent perpetua consequat, et nis.</p>
                        </div>
                    </div>
                </div>
            </section>
            
            <!--car-block-wrap ends-->
            <div class="row parallax_parent design_2 margin-bottom-40 margin-top-30" style="height: 385px;">
                <div class="parallax_scroll clearfix" data-velocity="-.5" data-offset="-200" data-image="themes/automovile/images/parallax1.jpg" style="background-image: url(&quot;themes/automovile/images/parallax1.jpg&quot;); background-position: 50% -219px;">
                    <div class="overlay">
                        <div class="container">
                            <div class="row">
                                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 padding-left-none xs-margin-bottom-none xs-padding-top-30 scroll_effect bounceInLeft animated" style="visibility: visible; animation-name: bounceInLeft;"> <span class="align-center"><i class="fa fa-6x fa-bar-chart-o"></i></span>
                                    <h3>Results Driven</h3>
                                    <p>Sed ut perspiciatis unde om nis
                                        natus error sit volup atem accusant 
                                        dolorem que laudantium. Totam 
                                        aperiam, eaque ipsa quae ai.</p>
                                </div>
                                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 xs-margin-bottom-none xs-padding-top-30 scroll_effect bounceInLeft animated" data-wow-delay=".2s" style="visibility: visible; animation-delay: 0.2s; animation-name: bounceInLeft;"> <span class="align-center"><i class="fa fa-6x fa-road"></i></span>
                                    <h3>Proven Technology</h3>
                                    <p>Sed ut perspiciatis unde om nis
                                        natus error sit volup atem accusant 
                                        dolorem que laudantium. Totam 
                                        aperiam, eaque ipsa quae ai.</p>
                                </div>
                                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 xs-margin-bottom-none xs-padding-top-30 scroll_effect bounceInRight animated" data-wow-delay=".2s" style="visibility: visible; animation-delay: 0.2s; animation-name: bounceInRight;"> <span class="align-center"><i class="fa fa-6x fa-flag-checkered"></i></span>
                                    <h3>Winning Culture</h3>
                                    <p>Sed ut perspiciatis unde om nis
                                        natus error sit volup atem accusant 
                                        dolorem que laudantium. Totam 
                                        aperiam, eaque ipsa quae ai.</p>
                                </div>
                                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 xs-margin-bottom-none xs-padding-top-30 padding-right-none scroll_effect bounceInRight animated" style="visibility: visible; animation-name: bounceInRight;"> <span class="align-center"><i class="fa fa-6x fa-dashboard"></i></span>
                                    <h3>Top Performance</h3>
                                    <p>Sed ut perspiciatis unde om nis
                                        natus error sit volup atem accusant 
                                        dolorem que laudantium. Totam 
                                        aperiam, eaque ipsa quae ai.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--car-info-wrap ends-->
            <section class="welcome-wrap padding-top-30 sm-horizontal-15">
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 welcome padding-left-none padding-bottom-40 scroll_effect fadeInUp animated" style="visibility: visible; animation-name: fadeInUp;">
                        <h4 class="margin-bottom-25 margin-top-none"><strong>WELCOME</strong> TO YOUR NEW WEBSITE</h4>
                        <p>Lorem ipsum dolor sit amet, falli tollit cetero te eos. Ea ullum liber aperiri mi, impetus
                            ate philosophia ad duo, quem regione ne ius. Vis quis lobortis dissentias ex, in du aft 
                            philosophia, malis necessitatibus no mei. Volumus sensibus qui ex, eum duis doming 
                            ad. Modo liberavisse eu mel, no viris prompta sit. Pro labore sadipscing et. Ne peax
                            egat usu te mel <span class="alternate-font">vivendo scriptorem</span>. Pro labore sadipscing et. Ne pertinax egat usu te 
                            mel vivendo scriptorem.</p>
                        <p>Cum ut tractatos imperdiet, no tamquam facilisi qui. Eum tibique consectetuer in, an 
                            referrentur vis, vocent deseruisse ex mel. Sed te <span class="alternate-font">idque graecis</span>. Vel ne libris dolores, 
                            mel graece mel vivendo scriptorem dolorum.</p>
                    </div>
                    <!--welcome ends-->
                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 padding-right-none sm-padding-left-none md-padding-left-15 xs-padding-left-none padding-bottom-40 scroll_effect fadeInUp animated" data-wow-delay=".2s" style="z-index: 100; visibility: visible; animation-delay: 0.2s; animation-name: fadeInUp;">
                        <h4 class="margin-bottom-25 margin-top-none"><strong>SEARCH</strong> OUR INVENTORY</h4>
                        <div class="search-form margin-top-20 padding-vertical-20">
                            <form method="post" action="https://demo.themesuite.com/automotive/#">
                                <div class="select-wrapper clearfix">
                                    <div class="col-md-6">
                                        <div class="min-price select-dropdown">
                                            <div class="my-dropdown min-price-dropdown min-dropdown">
                                                <select name="min-year" class="css-dropdowns" tabindex="1" sb="56594327" style="display: none;">
                                                    <option value="">Min Year</option>
                                                    <option>2015</option>
                                                    <option>2014</option>
                                                    <option>2013</option>
                                                    <option>2012</option>
                                                    <option>2011</option>
                                                    <option>2010</option>
                                                    <option>2009</option>
                                                    <option>2008</option>
                                                    <option>2007</option>
                                                    <option>2006</option>
                                                    <option>2005</option>
                                                    <option>2004</option>
                                                </select><div id="sbHolder_56594327" class="sbHolder" tabindex="1"><a id="sbToggle_56594327" href="https://demo.themesuite.com/automotive/#" class="sbToggle"></a><a id="sbSelector_56594327" href="https://demo.themesuite.com/automotive/#" class="sbSelector">Min Year</a><ul id="sbOptions_56594327" class="sbOptions" style="display: none;"><li><a href="https://demo.themesuite.com/automotive/#" rel="" class="sbFocus">Min Year</a></li><li><a href="https://demo.themesuite.com/automotive/#2015" rel="2015">2015</a></li><li><a href="https://demo.themesuite.com/automotive/#2014" rel="2014">2014</a></li><li><a href="https://demo.themesuite.com/automotive/#2013" rel="2013">2013</a></li><li><a href="https://demo.themesuite.com/automotive/#2012" rel="2012">2012</a></li><li><a href="https://demo.themesuite.com/automotive/#2011" rel="2011">2011</a></li><li><a href="https://demo.themesuite.com/automotive/#2010" rel="2010">2010</a></li><li><a href="https://demo.themesuite.com/automotive/#2009" rel="2009">2009</a></li><li><a href="https://demo.themesuite.com/automotive/#2008" rel="2008">2008</a></li><li><a href="https://demo.themesuite.com/automotive/#2007" rel="2007">2007</a></li><li><a href="https://demo.themesuite.com/automotive/#2006" rel="2006">2006</a></li><li><a href="https://demo.themesuite.com/automotive/#2005" rel="2005">2005</a></li><li><a href="https://demo.themesuite.com/automotive/#2004" rel="2004">2004</a></li></ul></div>
                                            </div>
                                            <span class="my-dropdown">to</span>
                                            <div class="my-dropdown max-price-dropdown min-dropdown">
                                                <select name="max-year" class="css-dropdowns" tabindex="1" sb="14595837" style="display: none;">
                                                    <option value="">Max Year</option>
                                                    <option>2015</option>
                                                    <option>2014</option>
                                                    <option>2013</option>
                                                    <option>2012</option>
                                                    <option>2011</option>
                                                    <option>2010</option>
                                                    <option>2009</option>
                                                    <option>2008</option>
                                                    <option>2007</option>
                                                    <option>2006</option>
                                                    <option>2005</option>
                                                    <option>2004</option>
                                                </select><div id="sbHolder_14595837" class="sbHolder" tabindex="1"><a id="sbToggle_14595837" href="https://demo.themesuite.com/automotive/#" class="sbToggle"></a><a id="sbSelector_14595837" href="https://demo.themesuite.com/automotive/#" class="sbSelector">Max Year</a><ul id="sbOptions_14595837" class="sbOptions" style="display: none;"><li><a href="https://demo.themesuite.com/automotive/#" rel="" class="sbFocus">Max Year</a></li><li><a href="https://demo.themesuite.com/automotive/#2015" rel="2015">2015</a></li><li><a href="https://demo.themesuite.com/automotive/#2014" rel="2014">2014</a></li><li><a href="https://demo.themesuite.com/automotive/#2013" rel="2013">2013</a></li><li><a href="https://demo.themesuite.com/automotive/#2012" rel="2012">2012</a></li><li><a href="https://demo.themesuite.com/automotive/#2011" rel="2011">2011</a></li><li><a href="https://demo.themesuite.com/automotive/#2010" rel="2010">2010</a></li><li><a href="https://demo.themesuite.com/automotive/#2009" rel="2009">2009</a></li><li><a href="https://demo.themesuite.com/automotive/#2008" rel="2008">2008</a></li><li><a href="https://demo.themesuite.com/automotive/#2007" rel="2007">2007</a></li><li><a href="https://demo.themesuite.com/automotive/#2006" rel="2006">2006</a></li><li><a href="https://demo.themesuite.com/automotive/#2005" rel="2005">2005</a></li><li><a href="https://demo.themesuite.com/automotive/#2004" rel="2004">2004</a></li></ul></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="min-price select-dropdown">
                                            <div class="my-dropdown min-price-dropdown min-dropdown">
                                                <select name="min-price" class="css-dropdowns" tabindex="1" sb="69870976" style="display: none;">
                                                    <option value="">Min Price</option>
                                                    <option>0</option>
                                                    <option>&lt; 10,000</option>
                                                    <option>&lt; 20,000</option>
                                                    <option>&lt; 30,000</option>
                                                    <option>&lt; 40,000</option>
                                                    <option>&lt; 50,000</option>
                                                    <option>&lt; 60,000</option>
                                                    <option>&lt; 70,000</option>
                                                    <option>&lt; 80,000</option>
                                                    <option>&lt; 90,000</option>
                                                    <option>&lt; 100,000</option>
                                                    <option>&lt; 120,000</option>
                                                    <option>&lt; 150,000</option>
                                                </select><div id="sbHolder_69870976" class="sbHolder" tabindex="1"><a id="sbToggle_69870976" href="https://demo.themesuite.com/automotive/#" class="sbToggle"></a><a id="sbSelector_69870976" href="https://demo.themesuite.com/automotive/#" class="sbSelector">Min Price</a><ul id="sbOptions_69870976" class="sbOptions" style="display: none;"><li><a href="https://demo.themesuite.com/automotive/#" rel="" class="sbFocus">Min Price</a></li><li><a href="https://demo.themesuite.com/automotive/#0" rel="0">0</a></li><li><a href="https://demo.themesuite.com/automotive/#&lt; 10,000" rel="&lt; 10,000">&lt; 10,000</a></li><li><a href="https://demo.themesuite.com/automotive/#&lt; 20,000" rel="&lt; 20,000">&lt; 20,000</a></li><li><a href="https://demo.themesuite.com/automotive/#&lt; 30,000" rel="&lt; 30,000">&lt; 30,000</a></li><li><a href="https://demo.themesuite.com/automotive/#&lt; 40,000" rel="&lt; 40,000">&lt; 40,000</a></li><li><a href="https://demo.themesuite.com/automotive/#&lt; 50,000" rel="&lt; 50,000">&lt; 50,000</a></li><li><a href="https://demo.themesuite.com/automotive/#&lt; 60,000" rel="&lt; 60,000">&lt; 60,000</a></li><li><a href="https://demo.themesuite.com/automotive/#&lt; 70,000" rel="&lt; 70,000">&lt; 70,000</a></li><li><a href="https://demo.themesuite.com/automotive/#&lt; 80,000" rel="&lt; 80,000">&lt; 80,000</a></li><li><a href="https://demo.themesuite.com/automotive/#&lt; 90,000" rel="&lt; 90,000">&lt; 90,000</a></li><li><a href="https://demo.themesuite.com/automotive/#&lt; 100,000" rel="&lt; 100,000">&lt; 100,000</a></li><li><a href="https://demo.themesuite.com/automotive/#&lt; 120,000" rel="&lt; 120,000">&lt; 120,000</a></li><li><a href="https://demo.themesuite.com/automotive/#&lt; 150,000" rel="&lt; 150,000">&lt; 150,000</a></li></ul></div>
                                            </div>
                                            <span class="my-dropdown">to</span>
                                            <div class="my-dropdown max-price-dropdown min-dropdown">
                                                <select name="max-price" class="css-dropdowns" tabindex="1" sb="85753327" style="display: none;">
                                                    <option value="">Max Price</option>
                                                    <option>0</option>
                                                    <option>&lt; 10,000</option>
                                                    <option>&lt; 20,000</option>
                                                    <option>&lt; 30,000</option>
                                                    <option>&lt; 40,000</option>
                                                    <option>&lt; 50,000</option>
                                                    <option>&lt; 60,000</option>
                                                    <option>&lt; 70,000</option>
                                                    <option>&lt; 80,000</option>
                                                    <option>&lt; 90,000</option>
                                                    <option>&lt; 100,000</option>
                                                    <option>&lt; 120,000</option>
                                                    <option>&lt; 150,000</option>
                                                </select><div id="sbHolder_85753327" class="sbHolder" tabindex="1"><a id="sbToggle_85753327" href="https://demo.themesuite.com/automotive/#" class="sbToggle"></a><a id="sbSelector_85753327" href="https://demo.themesuite.com/automotive/#" class="sbSelector">Max Price</a><ul id="sbOptions_85753327" class="sbOptions" style="display: none;"><li><a href="https://demo.themesuite.com/automotive/#" rel="" class="sbFocus">Max Price</a></li><li><a href="https://demo.themesuite.com/automotive/#0" rel="0">0</a></li><li><a href="https://demo.themesuite.com/automotive/#&lt; 10,000" rel="&lt; 10,000">&lt; 10,000</a></li><li><a href="https://demo.themesuite.com/automotive/#&lt; 20,000" rel="&lt; 20,000">&lt; 20,000</a></li><li><a href="https://demo.themesuite.com/automotive/#&lt; 30,000" rel="&lt; 30,000">&lt; 30,000</a></li><li><a href="https://demo.themesuite.com/automotive/#&lt; 40,000" rel="&lt; 40,000">&lt; 40,000</a></li><li><a href="https://demo.themesuite.com/automotive/#&lt; 50,000" rel="&lt; 50,000">&lt; 50,000</a></li><li><a href="https://demo.themesuite.com/automotive/#&lt; 60,000" rel="&lt; 60,000">&lt; 60,000</a></li><li><a href="https://demo.themesuite.com/automotive/#&lt; 70,000" rel="&lt; 70,000">&lt; 70,000</a></li><li><a href="https://demo.themesuite.com/automotive/#&lt; 80,000" rel="&lt; 80,000">&lt; 80,000</a></li><li><a href="https://demo.themesuite.com/automotive/#&lt; 90,000" rel="&lt; 90,000">&lt; 90,000</a></li><li><a href="https://demo.themesuite.com/automotive/#&lt; 100,000" rel="&lt; 100,000">&lt; 100,000</a></li><li><a href="https://demo.themesuite.com/automotive/#&lt; 120,000" rel="&lt; 120,000">&lt; 120,000</a></li><li><a href="https://demo.themesuite.com/automotive/#&lt; 150,000" rel="&lt; 150,000">&lt; 150,000</a></li></ul></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="select-wrapper clearfix">
                                    <div class="col-md-6">
                                        <div class="my-dropdown make-dropdown">
                                            <select name="body_style" class="css-dropdowns" tabindex="1" sb="18497945" style="display: none;">
                                                <option value="">Body Style</option>
                                                <option>Cargo</option>
                                                <option>Compact</option>
                                                <option>Convertible</option>
                                                <option>Coupe</option>
                                                <option>Hatchback</option>
                                                <option>Minivan</option>
                                                <option>Sedan</option>
                                                <option>SUV</option>
                                                <option>Truck</option>
                                                <option>Van</option>
                                                <option>Wagon</option>
                                            </select><div id="sbHolder_18497945" class="sbHolder" tabindex="1"><a id="sbToggle_18497945" href="https://demo.themesuite.com/automotive/#" class="sbToggle"></a><a id="sbSelector_18497945" href="https://demo.themesuite.com/automotive/#" class="sbSelector">Body Style</a><ul id="sbOptions_18497945" class="sbOptions" style="display: none;"><li><a href="https://demo.themesuite.com/automotive/#" rel="" class="sbFocus">Body Style</a></li><li><a href="https://demo.themesuite.com/automotive/#Cargo" rel="Cargo">Cargo</a></li><li><a href="https://demo.themesuite.com/automotive/#Compact" rel="Compact">Compact</a></li><li><a href="https://demo.themesuite.com/automotive/#Convertible" rel="Convertible">Convertible</a></li><li><a href="https://demo.themesuite.com/automotive/#Coupe" rel="Coupe">Coupe</a></li><li><a href="https://demo.themesuite.com/automotive/#Hatchback" rel="Hatchback">Hatchback</a></li><li><a href="https://demo.themesuite.com/automotive/#Minivan" rel="Minivan">Minivan</a></li><li><a href="https://demo.themesuite.com/automotive/#Sedan" rel="Sedan">Sedan</a></li><li><a href="https://demo.themesuite.com/automotive/#SUV" rel="SUV">SUV</a></li><li><a href="https://demo.themesuite.com/automotive/#Truck" rel="Truck">Truck</a></li><li><a href="https://demo.themesuite.com/automotive/#Van" rel="Van">Van</a></li><li><a href="https://demo.themesuite.com/automotive/#Wagon" rel="Wagon">Wagon</a></li></ul></div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="min-price select-dropdown">
                                            <div class="my-dropdown min-price-dropdown min-dropdown">
                                                <select name="min-mileage" class="css-dropdowns" tabindex="1" sb="50779982" style="display: none;">
                                                    <option value="">Min Mileage</option>
                                                    <option>0</option>
                                                    <option>&lt; 10,000</option>
                                                    <option>&lt; 20,000</option>
                                                    <option>&lt; 30,000</option>
                                                    <option>&lt; 40,000</option>
                                                    <option>&lt; 50,000</option>
                                                    <option>&lt; 60,000</option>
                                                    <option>&lt; 70,000</option>
                                                    <option>&lt; 80,000</option>
                                                    <option>&lt; 90,000</option>
                                                    <option>&lt; 100,000</option>
                                                    <option>&lt; 120,000</option>
                                                    <option>&lt; 150,000</option>
                                                </select><div id="sbHolder_50779982" class="sbHolder" tabindex="1"><a id="sbToggle_50779982" href="https://demo.themesuite.com/automotive/#" class="sbToggle"></a><a id="sbSelector_50779982" href="https://demo.themesuite.com/automotive/#" class="sbSelector">Min Mileage</a><ul id="sbOptions_50779982" class="sbOptions" style="display: none;"><li><a href="https://demo.themesuite.com/automotive/#" rel="" class="sbFocus">Min Mileage</a></li><li><a href="https://demo.themesuite.com/automotive/#0" rel="0">0</a></li><li><a href="https://demo.themesuite.com/automotive/#&lt; 10,000" rel="&lt; 10,000">&lt; 10,000</a></li><li><a href="https://demo.themesuite.com/automotive/#&lt; 20,000" rel="&lt; 20,000">&lt; 20,000</a></li><li><a href="https://demo.themesuite.com/automotive/#&lt; 30,000" rel="&lt; 30,000">&lt; 30,000</a></li><li><a href="https://demo.themesuite.com/automotive/#&lt; 40,000" rel="&lt; 40,000">&lt; 40,000</a></li><li><a href="https://demo.themesuite.com/automotive/#&lt; 50,000" rel="&lt; 50,000">&lt; 50,000</a></li><li><a href="https://demo.themesuite.com/automotive/#&lt; 60,000" rel="&lt; 60,000">&lt; 60,000</a></li><li><a href="https://demo.themesuite.com/automotive/#&lt; 70,000" rel="&lt; 70,000">&lt; 70,000</a></li><li><a href="https://demo.themesuite.com/automotive/#&lt; 80,000" rel="&lt; 80,000">&lt; 80,000</a></li><li><a href="https://demo.themesuite.com/automotive/#&lt; 90,000" rel="&lt; 90,000">&lt; 90,000</a></li><li><a href="https://demo.themesuite.com/automotive/#&lt; 100,000" rel="&lt; 100,000">&lt; 100,000</a></li><li><a href="https://demo.themesuite.com/automotive/#&lt; 120,000" rel="&lt; 120,000">&lt; 120,000</a></li><li><a href="https://demo.themesuite.com/automotive/#&lt; 150,000" rel="&lt; 150,000">&lt; 150,000</a></li></ul></div>
                                            </div>
                                            <span class="my-dropdown">to</span>
                                            <div class="my-dropdown max-price-dropdown min-dropdown">
                                                <select name="max-mileage" class="css-dropdowns" tabindex="1" sb="31549214" style="display: none;">
                                                    <option value="">Max Mileage</option>
                                                    <option>0</option>
                                                    <option>&lt; 10,000</option>
                                                    <option>&lt; 20,000</option>
                                                    <option>&lt; 30,000</option>
                                                    <option>&lt; 40,000</option>
                                                    <option>&lt; 50,000</option>
                                                    <option>&lt; 60,000</option>
                                                    <option>&lt; 70,000</option>
                                                    <option>&lt; 80,000</option>
                                                    <option>&lt; 90,000</option>
                                                    <option>&lt; 100,000</option>
                                                    <option>&lt; 120,000</option>
                                                    <option>&lt; 150,000</option>
                                                </select><div id="sbHolder_31549214" class="sbHolder" tabindex="1"><a id="sbToggle_31549214" href="https://demo.themesuite.com/automotive/#" class="sbToggle"></a><a id="sbSelector_31549214" href="https://demo.themesuite.com/automotive/#" class="sbSelector">Max Mileage</a><ul id="sbOptions_31549214" class="sbOptions" style="display: none;"><li><a href="https://demo.themesuite.com/automotive/#" rel="" class="sbFocus">Max Mileage</a></li><li><a href="https://demo.themesuite.com/automotive/#0" rel="0">0</a></li><li><a href="https://demo.themesuite.com/automotive/#&lt; 10,000" rel="&lt; 10,000">&lt; 10,000</a></li><li><a href="https://demo.themesuite.com/automotive/#&lt; 20,000" rel="&lt; 20,000">&lt; 20,000</a></li><li><a href="https://demo.themesuite.com/automotive/#&lt; 30,000" rel="&lt; 30,000">&lt; 30,000</a></li><li><a href="https://demo.themesuite.com/automotive/#&lt; 40,000" rel="&lt; 40,000">&lt; 40,000</a></li><li><a href="https://demo.themesuite.com/automotive/#&lt; 50,000" rel="&lt; 50,000">&lt; 50,000</a></li><li><a href="https://demo.themesuite.com/automotive/#&lt; 60,000" rel="&lt; 60,000">&lt; 60,000</a></li><li><a href="https://demo.themesuite.com/automotive/#&lt; 70,000" rel="&lt; 70,000">&lt; 70,000</a></li><li><a href="https://demo.themesuite.com/automotive/#&lt; 80,000" rel="&lt; 80,000">&lt; 80,000</a></li><li><a href="https://demo.themesuite.com/automotive/#&lt; 90,000" rel="&lt; 90,000">&lt; 90,000</a></li><li><a href="https://demo.themesuite.com/automotive/#&lt; 100,000" rel="&lt; 100,000">&lt; 100,000</a></li><li><a href="https://demo.themesuite.com/automotive/#&lt; 120,000" rel="&lt; 120,000">&lt; 120,000</a></li><li><a href="https://demo.themesuite.com/automotive/#&lt; 150,000" rel="&lt; 150,000">&lt; 150,000</a></li></ul></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="select-wrapper clearfix">
                                    <div class="col-md-6">
                                        <div class="my-dropdown make-dropdown">
                                            <select name="model" class="css-dropdowns" tabindex="1" sb="52034397" style="display: none;">
                                                <option value="">Model</option>
                                                <option>Lorem</option>
                                                <option>ipsum</option>
                                                <option>dolor</option>
                                                <option>sit</option>
                                                <option>amet</option>
                                            </select><div id="sbHolder_52034397" class="sbHolder" tabindex="1"><a id="sbToggle_52034397" href="https://demo.themesuite.com/automotive/#" class="sbToggle"></a><a id="sbSelector_52034397" href="https://demo.themesuite.com/automotive/#" class="sbSelector">Model</a><ul id="sbOptions_52034397" class="sbOptions" style="display: none;"><li><a href="https://demo.themesuite.com/automotive/#" rel="" class="sbFocus">Model</a></li><li><a href="https://demo.themesuite.com/automotive/#Lorem" rel="Lorem">Lorem</a></li><li><a href="https://demo.themesuite.com/automotive/#ipsum" rel="ipsum">ipsum</a></li><li><a href="https://demo.themesuite.com/automotive/#dolor" rel="dolor">dolor</a></li><li><a href="https://demo.themesuite.com/automotive/#sit" rel="sit">sit</a></li><li><a href="https://demo.themesuite.com/automotive/#amet" rel="amet">amet</a></li></ul></div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="my-dropdown make-dropdown">
                                            <select name="transmission" class="css-dropdowns" tabindex="1" sb="46793457" style="display: none;">
                                                <option value="">Transmission</option>
                                                <option>Automatic</option>
                                                <option>Manual</option>
                                            </select><div id="sbHolder_46793457" class="sbHolder" tabindex="1"><a id="sbToggle_46793457" href="https://demo.themesuite.com/automotive/#" class="sbToggle"></a><a id="sbSelector_46793457" href="https://demo.themesuite.com/automotive/#" class="sbSelector">Transmission</a><ul id="sbOptions_46793457" class="sbOptions" style="display: none;"><li><a href="https://demo.themesuite.com/automotive/#" rel="" class="sbFocus">Transmission</a></li><li><a href="https://demo.themesuite.com/automotive/#Automatic" rel="Automatic">Automatic</a></li><li><a href="https://demo.themesuite.com/automotive/#Manual" rel="Manual">Manual</a></li></ul></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="select-wrapper clearfix">
                                    <div class="col-md-6">
                                        <div class="my-dropdown make-dropdown">
                                            <select name="make" class="css-dropdowns" tabindex="1" sb="19569256" style="display: none;">
                                                <option value="">Make</option>
                                                <option>Lorem</option>
                                                <option>ipsum</option>
                                                <option>dolor</option>
                                                <option>sit</option>
                                                <option>amet</option>
                                            </select><div id="sbHolder_19569256" class="sbHolder" tabindex="1"><a id="sbToggle_19569256" href="https://demo.themesuite.com/automotive/#" class="sbToggle"></a><a id="sbSelector_19569256" href="https://demo.themesuite.com/automotive/#" class="sbSelector">Make</a><ul id="sbOptions_19569256" class="sbOptions" style="display: none;"><li><a href="https://demo.themesuite.com/automotive/#" rel="" class="sbFocus">Make</a></li><li><a href="https://demo.themesuite.com/automotive/#Lorem" rel="Lorem">Lorem</a></li><li><a href="https://demo.themesuite.com/automotive/#ipsum" rel="ipsum">ipsum</a></li><li><a href="https://demo.themesuite.com/automotive/#dolor" rel="dolor">dolor</a></li><li><a href="https://demo.themesuite.com/automotive/#sit" rel="sit">sit</a></li><li><a href="https://demo.themesuite.com/automotive/#amet" rel="amet">amet</a></li></ul></div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="my-dropdown">
                                            <input class="full-width" type="search" value="" placeholder="Refine with keywords">
                                        </div>
                                    </div>
                                </div>
                                <div class="clear"></div>
                                <div class="select-wrapper clearfix">
                                    <div class="form-element clearfix">
                                        <input type="checkbox" id="check">
                                        <label for="check">Certified</label>
                                    </div>
                                    <div class="form-element">
                                        <input type="checkbox" id="check2">
                                        <label for="check2">CARFAX® Verified</label>
                                    </div>
                                    <div class="form-element">
                                        <input type="checkbox" id="check3">
                                        <label for="check3">Brand New</label>
                                    </div>
                                    <div class="form-element">
                                        <input type="submit" value="Find My New Vehicle" class="find_new_vehicle pull-right md-button">
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <!--invetory ends--> 
                </div>
                
                <div class="recent-vehicles-wrap margin-top-30 sm-padding-left-none padding-bottom-40">
                    <div class="row">
                        <div class="col-lg-2 col-md-2 col-sm-4 col-xs-12 recent-vehicles padding-left-none">
                            <h5 class="margin-top-none">Recent Vehicles</h5>
                            <p>Browse through the vast
                                selection of vehicles that
                                have recently been added
                                to our inventory.</p>
                            <div class="arrow3 clearfix margin-top-15 xs-margin-bottom-25" id="slideControls3"><span class="prev-btn"><a class="bx-prev" href="https://demo.themesuite.com/automotive/">Prev</a></span><span class="next-btn"><a class="bx-next" href="https://demo.themesuite.com/automotive/">Next</a></span></div>
                        </div>
                        <div class="col-md-10 col-sm-8 padding-right-none xs-padding-left-none">
                            <div class="bx-wrapper" style="max-width: 1170px; margin: 0px auto;"><div class="bx-viewport" style="width: 100%; overflow: hidden; position: relative; height: 188px;"><div class="carasouel-slider3" style="width: 1115%; position: relative; transition-duration: 0s; transform: translate3d(0px, 0px, 0px);">
                                <div class="slide" style="float: left; list-style: none; position: relative; margin-right: 30px; width: 170px;">
                                    <div class="angled_badge blue">
                                        <span>405 HP</span>
                                    </div>
                                    <div class="car-block">
                                        <div class="img-flex"> <a href="https://demo.themesuite.com/automotive/inventory-listing.html"><span class="align-center"><i class="fa fa-3x fa-plus-square-o"></i></span></a> <img src="./themes/automovile/index_files/c-car1.jpg" alt="" class="img-responsive"> </div>
                                        <div class="car-block-bottom">
                                            <h6><strong>2012 Porsche Cayenne GTS</strong></h6>
                                            <h6>1 Owner, 26,273 miles</h6>
                                            <h5>$ 102,995</h5>
                                        </div>
                                    </div>
                                </div>
                                <div class="slide" style="float: left; list-style: none; position: relative; margin-right: 30px; width: 170px;">
                                    <div class="angled_badge red">
                                        <span>Just Arrived</span>
                                    </div>
                                    <div class="car-block">
                                        <div class="img-flex"> <a href="https://demo.themesuite.com/automotive/inventory-listing.html"><span class="align-center"><i class="fa fa-3x fa-plus-square-o"></i></span></a> <img src="./themes/automovile/index_files/c-car2.jpg" alt="" class="img-responsive"> </div>
                                        <div class="car-block-bottom">
                                            <h6><strong>2009 Porsche Boxster</strong></h6>
                                            <h6>New Tires, 26,273 miles</h6>
                                            <h5>$ 34,995</h5>
                                        </div>
                                    </div>
                                </div>
                                <div class="slide" style="float: left; list-style: none; position: relative; margin-right: 30px; width: 170px;">
                                    <div class="car-block">
                                        <div class="img-flex"> <a href="https://demo.themesuite.com/automotive/inventory-listing.html"><span class="align-center"><i class="fa fa-3x fa-plus-square-o"></i></span></a> <img src="./themes/automovile/index_files/c-car3.jpg" alt="" class="img-responsive"> </div>
                                        <div class="car-block-bottom">
                                            <h6><strong>2013 Porsche Panamera S</strong></h6>
                                            <h6>Demonstrator, 7,088 miles</h6>
                                            <h5>$ 63,995</h5>
                                        </div>
                                    </div>
                                </div>
                                <div class="slide" style="float: left; list-style: none; position: relative; margin-right: 30px; width: 170px;">
                                    <div class="car-block">
                                        <div class="img-flex"> <a href="https://demo.themesuite.com/automotive/inventory-listing.html"><span class="align-center"><i class="fa fa-3x fa-plus-square-o"></i></span></a> <img src="./themes/automovile/index_files/c-car4.jpg" alt="" class="img-responsive"> </div>
                                        <div class="car-block-bottom">
                                            <h6><strong>2010 Porsche Carrera 4S</strong></h6>
                                            <h6>AWD, 21,900 miles</h6>
                                            <h5>$ 73,995</h5>
                                        </div>
                                    </div>
                                </div>
                                <div class="slide" style="float: left; list-style: none; position: relative; margin-right: 30px; width: 170px;">
                                    <div class="car-block">
                                        <div class="img-flex"> <a href="https://demo.themesuite.com/automotive/inventory-listing.html"><span class="align-center"><i class="fa fa-3x fa-plus-square-o"></i></span></a> <img src="./themes/automovile/index_files/c-car5.jpg" alt="" class="img-responsive"> </div>
                                        <div class="car-block-bottom">
                                            <h6><strong>2012 Porsche Carrera S</strong></h6>
                                            <h6>Convertible, 22,158 miles</h6>
                                            <h5>$ 56,995</h5>
                                        </div>
                                    </div>
                                </div>
                                <div class="slide" style="float: left; list-style: none; position: relative; margin-right: 30px; width: 170px;">
                                    <div class="car-block">
                                        <div class="img-flex"> <a href="https://demo.themesuite.com/automotive/inventory-listing.html"><span class="align-center"><i class="fa fa-3x fa-plus-square-o"></i></span></a> <img src="./themes/automovile/index_files/c-car6.jpg" alt="" class="img-responsive"> </div>
                                        <div class="car-block-bottom">
                                            <h6><strong>2013 Porsche Panamera GTS</strong></h6>
                                            <h6>1 Owner, 3,914 miles</h6>
                                            <h5>$ 94,995</h5>
                                        </div>
                                    </div>
                                </div>
                                <div class="slide" style="float: left; list-style: none; position: relative; margin-right: 30px; width: 170px;">
                                    <div class="car-block">
                                        <div class="img-flex"> <a href="https://demo.themesuite.com/automotive/inventory-listing.html"><span class="align-center"><i class="fa fa-3x fa-plus-square-o"></i></span></a> <img src="./themes/automovile/index_files/c-car7.jpg" alt="" class="img-responsive"> </div>
                                        <div class="car-block-bottom">
                                            <h6><strong>2014 Porsche Cayenne GTS</strong></h6>
                                            <h6>1 Owner, 7 miles</h6>
                                            <h5>$ 114,995</h5>
                                        </div>
                                    </div>
                                </div>
                                <div class="slide" style="float: left; list-style: none; position: relative; margin-right: 30px; width: 170px;">
                                    <span class="sold_text">Sold</span>
                                    <div class="car-block">
                                        <div class="img-flex"> <a href="https://demo.themesuite.com/automotive/inventory-listing.html"><span class="align-center"><i class="fa fa-3x fa-plus-square-o"></i></span></a> <img src="./themes/automovile/index_files/c-car8.jpg" alt="" class="img-responsive"> </div>
                                        <div class="car-block-bottom">
                                            <h6><strong>2014 Porsche GTS</strong></h6>
                                            <h6>1 Owner, 5 miles</h6>
                                            <h5>$ 99,995</h5>
                                        </div>
                                    </div>
                                </div>
                                <div class="slide" style="float: left; list-style: none; position: relative; margin-right: 30px; width: 170px;">
                                    <div class="car-block">
                                        <div class="img-flex"> <a href="https://demo.themesuite.com/automotive/inventory-listing.html"><span class="align-center"><i class="fa fa-3x fa-plus-square-o"></i></span></a> <img src="./themes/automovile/index_files/c-car9.jpg" alt="" class="img-responsive"> </div>
                                        <div class="car-block-bottom">
                                            <h6><strong>2009 Porsche Carrera 4S</strong></h6>
                                            <h6>1 Owner, 114,239 miles</h6>
                                            <h5>$ 39,995</h5>
                                        </div>
                                    </div>
                                </div>
                            </div></div><div class="bx-controls"></div></div>
                        </div>
                    </div>
                </div>
                
                <!-- Footer Map -->
                <div class="fullwidth_element_parent margin-top-30 padding-bottom-40" style="height: 430px;">
                    <div id="google-map-listing" class="fullwidth_element" data-longitude="-79.38" data-latitude="43.65" data-zoom="12" style="height: 390px; overflow: hidden;" data-scroll="false" data-style="[{&quot;featureType&quot;:&quot;landscape&quot;,&quot;elementType&quot;:&quot;labels&quot;,&quot;stylers&quot;:[{&quot;visibility&quot;:&quot;off&quot;}]},{&quot;featureType&quot;:&quot;transit&quot;,&quot;elementType&quot;:&quot;labels&quot;,&quot;stylers&quot;:[{&quot;visibility&quot;:&quot;off&quot;}]},{&quot;featureType&quot;:&quot;poi&quot;,&quot;elementType&quot;:&quot;labels&quot;,&quot;stylers&quot;:[{&quot;visibility&quot;:&quot;off&quot;}]},{&quot;featureType&quot;:&quot;water&quot;,&quot;elementType&quot;:&quot;labels&quot;,&quot;stylers&quot;:[{&quot;visibility&quot;:&quot;off&quot;}]},{&quot;featureType&quot;:&quot;road&quot;,&quot;elementType&quot;:&quot;labels.icon&quot;,&quot;stylers&quot;:[{&quot;visibility&quot;:&quot;off&quot;}]},{&quot;stylers&quot;:[{&quot;hue&quot;:&quot;#F0F0F0&quot;},{&quot;saturation&quot;:-100},{&quot;gamma&quot;:2.15},{&quot;lightness&quot;:12}]},{&quot;featureType&quot;:&quot;road&quot;,&quot;elementType&quot;:&quot;labels.text.fill&quot;,&quot;stylers&quot;:[{&quot;visibility&quot;:&quot;on&quot;},{&quot;lightness&quot;:24}]},{&quot;featureType&quot;:&quot;road&quot;,&quot;elementType&quot;:&quot;geometry&quot;,&quot;stylers&quot;:[{&quot;lightness&quot;:57}]}]"><div style="height: 100%; width: 100%; position: absolute; top: 0px; left: 0px; background-color: rgb(229, 227, 223);"><div class="gm-style" style="position: absolute; z-index: 0; left: 0px; top: 0px; height: 100%; width: 100%; padding: 0px; border-width: 0px; margin: 0px;"><div tabindex="0" style="position: absolute; z-index: 0; left: 0px; top: 0px; height: 100%; width: 100%; padding: 0px; border-width: 0px; margin: 0px; cursor: url(&quot;https://maps.gstatic.com/mapfiles/openhand_8_8.cur&quot;) 8 8, default;"><div style="z-index: 1; position: absolute; top: 0px; left: 0px; width: 100%; transform-origin: 675px 195px 0px; transform: matrix(1, 0, 0, 1, 0, 0);"><div style="position: absolute; left: 0px; top: 0px; z-index: 100; width: 100%;"><div style="position: absolute; left: 0px; top: 0px; z-index: 0;"><div aria-hidden="true" style="position: absolute; left: 0px; top: 0px; z-index: 1; visibility: inherit;"><div style="width: 256px; height: 256px; position: absolute; left: 718px; top: 213px;"></div><div style="width: 256px; height: 256px; position: absolute; left: 462px; top: 213px;"></div><div style="width: 256px; height: 256px; position: absolute; left: 974px; top: 213px;"></div><div style="width: 256px; height: 256px; position: absolute; left: 206px; top: 213px;"></div><div style="width: 256px; height: 256px; position: absolute; left: 1230px; top: 213px;"></div><div style="width: 256px; height: 256px; position: absolute; left: -50px; top: 213px;"></div><div style="width: 256px; height: 256px; position: absolute; left: 718px; top: -43px;"></div><div style="width: 256px; height: 256px; position: absolute; left: 462px; top: -43px;"></div><div style="width: 256px; height: 256px; position: absolute; left: 974px; top: -43px;"></div><div style="width: 256px; height: 256px; position: absolute; left: 206px; top: -43px;"></div><div style="width: 256px; height: 256px; position: absolute; left: 1230px; top: -43px;"></div><div style="width: 256px; height: 256px; position: absolute; left: -50px; top: -43px;"></div></div></div></div><div style="position: absolute; left: 0px; top: 0px; z-index: 101; width: 100%;"></div><div style="position: absolute; left: 0px; top: 0px; z-index: 102; width: 100%;"></div><div style="position: absolute; left: 0px; top: 0px; z-index: 103; width: 100%;"><div style="position: absolute; left: 0px; top: 0px; z-index: -1;"><div aria-hidden="true" style="position: absolute; left: 0px; top: 0px; z-index: 1; visibility: inherit;"><div style="width: 256px; height: 256px; overflow: hidden; position: absolute; left: 718px; top: 213px;"></div><div style="width: 256px; height: 256px; overflow: hidden; position: absolute; left: 462px; top: 213px;"></div><div style="width: 256px; height: 256px; overflow: hidden; position: absolute; left: 974px; top: 213px;"></div><div style="width: 256px; height: 256px; overflow: hidden; position: absolute; left: 206px; top: 213px;"></div><div style="width: 256px; height: 256px; overflow: hidden; position: absolute; left: 1230px; top: 213px;"></div><div style="width: 256px; height: 256px; overflow: hidden; position: absolute; left: -50px; top: 213px;"></div><div style="width: 256px; height: 256px; overflow: hidden; position: absolute; left: 718px; top: -43px;"></div><div style="width: 256px; height: 256px; overflow: hidden; position: absolute; left: 462px; top: -43px;"></div><div style="width: 256px; height: 256px; overflow: hidden; position: absolute; left: 974px; top: -43px;"></div><div style="width: 256px; height: 256px; overflow: hidden; position: absolute; left: 206px; top: -43px;"></div><div style="width: 256px; height: 256px; overflow: hidden; position: absolute; left: 1230px; top: -43px;"></div><div style="width: 256px; height: 256px; overflow: hidden; position: absolute; left: -50px; top: -43px;"></div></div></div></div><div style="position: absolute; left: 0px; top: 0px; z-index: 0;"><div aria-hidden="true" style="position: absolute; left: 0px; top: 0px; z-index: 1; visibility: inherit;"><div style="position: absolute; left: 718px; top: 213px;"><img draggable="false" alt="" src="./themes/automovile/index_files/vt" style="width: 256px; height: 256px; user-select: none; border: 0px; padding: 0px; margin: 0px; max-width: none;"></div><div style="position: absolute; left: 462px; top: 213px;"><img draggable="false" alt="" src="./themes/automovile/index_files/vt(1)" style="width: 256px; height: 256px; user-select: none; border: 0px; padding: 0px; margin: 0px; max-width: none;"></div><div style="position: absolute; left: 974px; top: 213px;"><img draggable="false" alt="" src="./themes/automovile/index_files/vt(2)" style="width: 256px; height: 256px; user-select: none; border: 0px; padding: 0px; margin: 0px; max-width: none;"></div><div style="position: absolute; left: 206px; top: 213px;"><img draggable="false" alt="" src="./themes/automovile/index_files/vt(3)" style="width: 256px; height: 256px; user-select: none; border: 0px; padding: 0px; margin: 0px; max-width: none;"></div><div style="position: absolute; left: 1230px; top: 213px;"><img draggable="false" alt="" src="./themes/automovile/index_files/vt(4)" style="width: 256px; height: 256px; user-select: none; border: 0px; padding: 0px; margin: 0px; max-width: none;"></div><div style="position: absolute; left: -50px; top: 213px;"><img draggable="false" alt="" src="./themes/automovile/index_files/vt(5)" style="width: 256px; height: 256px; user-select: none; border: 0px; padding: 0px; margin: 0px; max-width: none;"></div><div style="position: absolute; left: 718px; top: -43px;"><img draggable="false" alt="" src="./themes/automovile/index_files/vt(6)" style="width: 256px; height: 256px; user-select: none; border: 0px; padding: 0px; margin: 0px; max-width: none;"></div><div style="position: absolute; left: 462px; top: -43px;"><img draggable="false" alt="" src="./themes/automovile/index_files/vt(7)" style="width: 256px; height: 256px; user-select: none; border: 0px; padding: 0px; margin: 0px; max-width: none;"></div><div style="position: absolute; left: 974px; top: -43px;"><img draggable="false" alt="" src="./themes/automovile/index_files/vt(8)" style="width: 256px; height: 256px; user-select: none; border: 0px; padding: 0px; margin: 0px; max-width: none;"></div><div style="position: absolute; left: 206px; top: -43px;"><img draggable="false" alt="" src="./themes/automovile/index_files/vt(9)" style="width: 256px; height: 256px; user-select: none; border: 0px; padding: 0px; margin: 0px; max-width: none;"></div><div style="position: absolute; left: 1230px; top: -43px;"><img draggable="false" alt="" src="./themes/automovile/index_files/vt(10)" style="width: 256px; height: 256px; user-select: none; border: 0px; padding: 0px; margin: 0px; max-width: none;"></div><div style="position: absolute; left: -50px; top: -43px;"><img draggable="false" alt="" src="./themes/automovile/index_files/vt(11)" style="width: 256px; height: 256px; user-select: none; border: 0px; padding: 0px; margin: 0px; max-width: none;"></div></div></div></div><div class="gm-style-pbc" style="z-index: 2; position: absolute; height: 100%; width: 100%; padding: 0px; border-width: 0px; margin: 0px; left: 0px; top: 0px; opacity: 0;"><p class="gm-style-pbt"></p></div><div style="z-index: 3; position: absolute; height: 100%; width: 100%; padding: 0px; border-width: 0px; margin: 0px; left: 0px; top: 0px;"><div style="z-index: 1; position: absolute; height: 100%; width: 100%; padding: 0px; border-width: 0px; margin: 0px; left: 0px; top: 0px;"></div></div><div style="z-index: 4; position: absolute; top: 0px; left: 0px; width: 100%; transform-origin: 675px 195px 0px; transform: matrix(1, 0, 0, 1, 0, 0);"><div style="position: absolute; left: 0px; top: 0px; z-index: 104; width: 100%;"></div><div style="position: absolute; left: 0px; top: 0px; z-index: 105; width: 100%;"></div><div style="position: absolute; left: 0px; top: 0px; z-index: 106; width: 100%;"></div><div style="position: absolute; left: 0px; top: 0px; z-index: 107; width: 100%;"></div></div></div><div style="margin-left: 5px; margin-right: 5px; z-index: 1000000; position: absolute; left: 0px; bottom: 0px;"><a target="_blank" href="https://maps.google.com/maps?ll=43.838914,-79.38&amp;z=12&amp;t=m&amp;hl=es-ES&amp;gl=US&amp;mapclient=apiv3" title="Haz clic aquí para visualizar esta zona en Google Maps" style="position: static; overflow: visible; float: none; display: inline;"><div style="width: 66px; height: 26px; cursor: pointer;"><img alt="" src="./themes/automovile/index_files/google_white5.png" draggable="false" style="position: absolute; left: 0px; top: 0px; width: 66px; height: 26px; user-select: none; border: 0px; padding: 0px; margin: 0px;"></div></a></div><div style="background-color: white; padding: 15px 21px; border: 1px solid rgb(171, 171, 171); font-family: Roboto, Arial, sans-serif; color: rgb(34, 34, 34); box-shadow: rgba(0, 0, 0, 0.2) 0px 4px 16px; z-index: 10000002; display: none; width: 256px; height: 148px; position: absolute; left: 525px; top: 105px;"><div style="padding: 0px 0px 10px; font-size: 16px;">Datos de mapas</div><div style="font-size: 13px;">Datos de mapas ©2017 Google</div><div style="width: 13px; height: 13px; overflow: hidden; position: absolute; opacity: 0.7; right: 12px; top: 12px; z-index: 10000; cursor: pointer;"><img alt="" src="./themes/automovile/index_files/mapcnt6.png" draggable="false" style="position: absolute; left: -2px; top: -336px; width: 59px; height: 492px; user-select: none; border: 0px; padding: 0px; margin: 0px; max-width: none;"></div></div><div class="gmnoprint" style="z-index: 1000001; position: absolute; right: 228px; bottom: 0px; width: 151px;"><div draggable="false" class="gm-style-cc" style="user-select: none; height: 14px; line-height: 14px;"><div style="opacity: 0.7; width: 100%; height: 100%; position: absolute;"><div style="width: 1px;"></div><div style="background-color: rgb(245, 245, 245); width: auto; height: 100%; margin-left: 1px;"></div></div><div style="position: relative; padding-right: 6px; padding-left: 6px; font-family: Roboto, Arial, sans-serif; font-size: 10px; color: rgb(68, 68, 68); white-space: nowrap; direction: ltr; text-align: right; vertical-align: middle; display: inline-block;"><a style="color: rgb(68, 68, 68); text-decoration: none; cursor: pointer; display: none;">Datos de mapas</a><span style="">Datos de mapas ©2017 Google</span></div></div></div><div class="gmnoscreen" style="position: absolute; right: 0px; bottom: 0px;"><div style="font-family: Roboto, Arial, sans-serif; font-size: 11px; color: rgb(68, 68, 68); direction: ltr; text-align: right; background-color: rgb(245, 245, 245);">Datos de mapas ©2017 Google</div></div><div class="gmnoprint gm-style-cc" draggable="false" style="z-index: 1000001; user-select: none; height: 14px; line-height: 14px; position: absolute; right: 142px; bottom: 0px;"><div style="opacity: 0.7; width: 100%; height: 100%; position: absolute;"><div style="width: 1px;"></div><div style="background-color: rgb(245, 245, 245); width: auto; height: 100%; margin-left: 1px;"></div></div><div style="position: relative; padding-right: 6px; padding-left: 6px; font-family: Roboto, Arial, sans-serif; font-size: 10px; color: rgb(68, 68, 68); white-space: nowrap; direction: ltr; text-align: right; vertical-align: middle; display: inline-block;"><a href="https://www.google.com/intl/es-ES_US/help/terms_maps.html" target="_blank" style="text-decoration: none; cursor: pointer; color: rgb(68, 68, 68);">Términos de uso</a></div></div><button draggable="false" title="Cambiar a la vista en pantalla completa" aria-label="Cambiar a la vista en pantalla completa" type="button" style="background: none; border: 0px; margin: 10px 14px; padding: 0px; position: absolute; cursor: pointer; user-select: none; width: 25px; height: 25px; overflow: hidden; top: 0px; right: 0px;"><img alt="" src="./themes/automovile/index_files/sv9.png" draggable="false" class="gm-fullscreen-control" style="position: absolute; left: -52px; top: -86px; width: 164px; height: 175px; user-select: none; border: 0px; padding: 0px; margin: 0px;"></button><div draggable="false" class="gm-style-cc" style="user-select: none; height: 14px; line-height: 14px; position: absolute; right: 0px; bottom: 0px;"><div style="opacity: 0.7; width: 100%; height: 100%; position: absolute;"><div style="width: 1px;"></div><div style="background-color: rgb(245, 245, 245); width: auto; height: 100%; margin-left: 1px;"></div></div><div style="position: relative; padding-right: 6px; padding-left: 6px; font-family: Roboto, Arial, sans-serif; font-size: 10px; color: rgb(68, 68, 68); white-space: nowrap; direction: ltr; text-align: right; vertical-align: middle; display: inline-block;"><a target="_new" title="Informar a Google acerca de errores en las imágenes o en el mapa de carreteras" href="https://www.google.com/maps/@43.8389136,-79.38,12z/data=!10m1!1e1!12b1?source=apiv3&amp;rapsrc=apiv3" style="font-family: Roboto, Arial, sans-serif; font-size: 10px; color: rgb(68, 68, 68); text-decoration: none; position: relative;">Informar de un error de Maps</a></div></div><div class="gmnoprint gm-bundled-control gm-bundled-control-on-bottom" draggable="false" controlwidth="28" controlheight="93" style="margin: 10px; user-select: none; position: absolute; bottom: 107px; right: 28px;"><div class="gmnoprint" controlwidth="28" controlheight="55" style="position: absolute; left: 0px; top: 38px;"><div draggable="false" style="user-select: none; box-shadow: rgba(0, 0, 0, 0.3) 0px 1px 4px -1px; border-radius: 2px; cursor: pointer; background-color: rgb(255, 255, 255); width: 28px; height: 55px;"><button draggable="false" title="Acerca la imagen" aria-label="Acerca la imagen" type="button" style="background: none; display: block; border: 0px; margin: 0px; padding: 0px; position: relative; cursor: pointer; user-select: none; width: 28px; height: 27px; top: 0px; left: 0px;"><div style="overflow: hidden; position: absolute; width: 15px; height: 15px; left: 7px; top: 6px;"><img alt="" src="./themes/automovile/index_files/tmapctrl.png" draggable="false" style="position: absolute; left: 0px; top: 0px; user-select: none; border: 0px; padding: 0px; margin: 0px; max-width: none; width: 120px; height: 54px;"></div></button><div style="position: relative; overflow: hidden; width: 67%; height: 1px; left: 16%; background-color: rgb(230, 230, 230); top: 0px;"></div><button draggable="false" title="Aleja la imagen" aria-label="Aleja la imagen" type="button" style="background: none; display: block; border: 0px; margin: 0px; padding: 0px; position: relative; cursor: pointer; user-select: none; width: 28px; height: 27px; top: 0px; left: 0px;"><div style="overflow: hidden; position: absolute; width: 15px; height: 15px; left: 7px; top: 6px;"><img alt="" src="./themes/automovile/index_files/tmapctrl.png" draggable="false" style="position: absolute; left: 0px; top: -15px; user-select: none; border: 0px; padding: 0px; margin: 0px; max-width: none; width: 120px; height: 54px;"></div></button></div></div><div class="gm-svpc" controlwidth="28" controlheight="28" style="background-color: rgb(255, 255, 255); box-shadow: rgba(0, 0, 0, 0.3) 0px 1px 4px -1px; border-radius: 2px; width: 28px; height: 28px; cursor: url(&quot;https://maps.gstatic.com/mapfiles/openhand_8_8.cur&quot;) 8 8, default; position: absolute; left: 0px; top: 0px;"><div style="position: absolute; left: 1px; top: 1px;"></div><div style="position: absolute; left: 1px; top: 1px;"><div aria-label="Control del hombrecito naranja de Street View" style="width: 26px; height: 26px; overflow: hidden; position: absolute; left: 0px; top: 0px;"><img alt="" src="./themes/automovile/index_files/cb_scout5.png" draggable="false" style="position: absolute; left: -147px; top: -26px; width: 215px; height: 835px; user-select: none; border: 0px; padding: 0px; margin: 0px; max-width: none;"></div><div aria-label="El hombrecito naranja está en la parte superior del mapa" style="width: 26px; height: 26px; overflow: hidden; position: absolute; left: 0px; top: 0px; visibility: hidden;"><img alt="" src="./themes/automovile/index_files/cb_scout5.png" draggable="false" style="position: absolute; left: -147px; top: -52px; width: 215px; height: 835px; user-select: none; border: 0px; padding: 0px; margin: 0px; max-width: none;"></div><div aria-label="Control del hombrecito naranja de Street View" style="width: 26px; height: 26px; overflow: hidden; position: absolute; left: 0px; top: 0px; visibility: hidden;"><img alt="" src="./themes/automovile/index_files/cb_scout5.png" draggable="false" style="position: absolute; left: -147px; top: -78px; width: 215px; height: 835px; user-select: none; border: 0px; padding: 0px; margin: 0px; max-width: none;"></div></div></div><div class="gmnoprint" controlwidth="28" controlheight="0" style="display: none; position: absolute;"><div title="Girar el mapa 90 grados" style="width: 28px; height: 28px; overflow: hidden; position: absolute; background-color: rgb(255, 255, 255); box-shadow: rgba(0, 0, 0, 0.3) 0px 1px 4px -1px; border-radius: 2px; cursor: pointer; display: none;"><img alt="" src="./themes/automovile/index_files/tmapctrl4.png" draggable="false" style="position: absolute; left: -141px; top: 6px; width: 170px; height: 54px; user-select: none; border: 0px; padding: 0px; margin: 0px; max-width: none;"></div><div class="gm-tilt" style="width: 28px; height: 28px; overflow: hidden; position: absolute; background-color: rgb(255, 255, 255); box-shadow: rgba(0, 0, 0, 0.3) 0px 1px 4px -1px; border-radius: 2px; top: 0px; cursor: pointer;"><img alt="" src="./themes/automovile/index_files/tmapctrl4.png" draggable="false" style="position: absolute; left: -141px; top: -13px; width: 170px; height: 54px; user-select: none; border: 0px; padding: 0px; margin: 0px; max-width: none;"></div></div></div><div class="gmnoprint" style="margin: 10px; z-index: 0; position: absolute; cursor: pointer; left: 0px; top: 0px;"><div class="gm-style-mtc" style="float: left; position: relative;"><div role="button" tabindex="0" title="Muestra el callejero" aria-label="Muestra el callejero" aria-pressed="true" draggable="false" style="direction: ltr; overflow: hidden; text-align: center; position: relative; color: rgb(0, 0, 0); font-family: Roboto, Arial, sans-serif; user-select: none; font-size: 11px; background-color: rgb(255, 255, 255); padding: 8px; border-bottom-left-radius: 2px; border-top-left-radius: 2px; -webkit-background-clip: padding-box; background-clip: padding-box; box-shadow: rgba(0, 0, 0, 0.3) 0px 1px 4px -1px; min-width: 28px; font-weight: 500;">Mapa</div><div style="background-color: white; z-index: -1; padding: 2px; border-bottom-left-radius: 2px; border-bottom-right-radius: 2px; box-shadow: rgba(0, 0, 0, 0.3) 0px 1px 4px -1px; position: absolute; left: 0px; top: 29px; text-align: left; display: none;"><div draggable="false" title="Muestra el callejero con relieve" style="color: rgb(0, 0, 0); font-family: Roboto, Arial, sans-serif; user-select: none; font-size: 11px; background-color: rgb(255, 255, 255); padding: 6px 8px 6px 6px; direction: ltr; text-align: left; white-space: nowrap;"><span role="checkbox" style="box-sizing: border-box; position: relative; line-height: 0; font-size: 0px; margin: 0px 5px 0px 0px; display: inline-block; background-color: rgb(255, 255, 255); border: 1px solid rgb(198, 198, 198); border-radius: 1px; width: 13px; height: 13px; vertical-align: middle;"><div style="position: absolute; left: 1px; top: -2px; width: 13px; height: 11px; overflow: hidden; display: none;"><img alt="" src="./themes/automovile/index_files/imgs8.png" draggable="false" style="position: absolute; left: -52px; top: -44px; user-select: none; border: 0px; padding: 0px; margin: 0px; max-width: none; width: 68px; height: 67px;"></div></span><label style="vertical-align: middle; cursor: pointer;">Relieve</label></div></div></div><div class="gm-style-mtc" style="float: left; position: relative;"><div role="button" tabindex="0" title="Muestra las imágenes de satélite" aria-label="Muestra las imágenes de satélite" aria-pressed="false" draggable="false" style="direction: ltr; overflow: hidden; text-align: center; position: relative; color: rgb(86, 86, 86); font-family: Roboto, Arial, sans-serif; user-select: none; font-size: 11px; background-color: rgb(255, 255, 255); padding: 8px; border-bottom-right-radius: 2px; border-top-right-radius: 2px; -webkit-background-clip: padding-box; background-clip: padding-box; box-shadow: rgba(0, 0, 0, 0.3) 0px 1px 4px -1px; min-width: 37px; border-left: 0px;">Satélite</div><div style="background-color: white; z-index: -1; padding: 2px; border-bottom-left-radius: 2px; border-bottom-right-radius: 2px; box-shadow: rgba(0, 0, 0, 0.3) 0px 1px 4px -1px; position: absolute; right: 0px; top: 29px; text-align: left; display: none;"><div draggable="false" title="Muestra las imágenes con los nombres de las calles" style="color: rgb(0, 0, 0); font-family: Roboto, Arial, sans-serif; user-select: none; font-size: 11px; background-color: rgb(255, 255, 255); padding: 6px 8px 6px 6px; direction: ltr; text-align: left; white-space: nowrap;"><span role="checkbox" style="box-sizing: border-box; position: relative; line-height: 0; font-size: 0px; margin: 0px 5px 0px 0px; display: inline-block; background-color: rgb(255, 255, 255); border: 1px solid rgb(198, 198, 198); border-radius: 1px; width: 13px; height: 13px; vertical-align: middle;"><div style="position: absolute; left: 1px; top: -2px; width: 13px; height: 11px; overflow: hidden;"><img alt="" src="./themes/automovile/index_files/imgs8.png" draggable="false" style="position: absolute; left: -52px; top: -44px; user-select: none; border: 0px; padding: 0px; margin: 0px; max-width: none; width: 68px; height: 67px;"></div></span><label style="vertical-align: middle; cursor: pointer;">Etiquetas</label></div></div></div></div></div></div></div>
                </div>
                <div class="car-rate-block clearfix margin-top-30 padding-bottom-40">
                    <div class="col-lg-2 col-md-2 col-sm-6 col-xs-12 xs-margin-bottom-40 sm-margin-bottom-none padding-left-none scroll_effect bounceInLeft animated" style="visibility: visible; animation-name: bounceInLeft;">
                        <div class="small-block clearfix">
                            <h4 class="margin-bottom-25 margin-top-none">Financing.</h4>
                            <a href="https://demo.themesuite.com/automotive/#"><span class="align-center"><i class="fa fa-tag fa-7x"></i></span></a> </div>
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-6 col-xs-12 xs-margin-bottom-40 sm-margin-bottom-none scroll_effect bounceInLeft animated" data-wow-delay=".2s" style="visibility: visible; animation-delay: 0.2s; animation-name: bounceInLeft;">
                        <div class="small-block clearfix">
                            <h4 class="margin-bottom-25 margin-top-none">Warranty.</h4>
                            <a href="https://demo.themesuite.com/automotive/#"><span class="align-center"><i class="fa fa-cogs fa-7x"></i></span></a> </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 padding-left-none padding-right-none hours_operation">
                        <div class="small-block clearfix">
                            <h4 class="margin-bottom-25 margin-top-none">What are our Hours of Operation?</h4>
                            <div class="row">
                                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 xs-margin-bottom-40 sm-margin-bottom-40 md-margin-bottom-none scroll_effect bounceInUp animated" data-wow-delay=".4s" style="visibility: visible; animation-delay: 0.4s; animation-name: bounceInUp;">
                                    <table class="table table-bordered no-border font-13px margin-bottom-none">
                                        <thead>
                                            <tr>
                                                <td colspan="2"><strong>Sales Department</strong></td>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>Mon:</td>
                                                <td>8:00am - 5:00pm</td>
                                            </tr>
                                            <tr>
                                                <td>Tue:</td>
                                                <td>8:00am - 9:00pm</td>
                                            </tr>
                                            <tr>
                                                <td>Wed:</td>
                                                <td>8:00am - 5:00pm</td>
                                            </tr>
                                            <tr>
                                                <td>Thu:</td>
                                                <td>8:00am - 9:00pm</td>
                                            </tr>
                                            <tr>
                                                <td>Fri:</td>
                                                <td>8:00am - 6:00pm</td>
                                            </tr>
                                            <tr>
                                                <td>Sat:</td>
                                                <td>9:00am - 5:00pm</td>
                                            </tr>
                                            <tr>
                                                <td>Sun:</td>
                                                <td>Closed</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 xs-margin-bottom-40 sm-margin-bottom-none scroll_effect bounceInUp animated" data-wow-delay=".4s" style="visibility: visible; animation-delay: 0.4s; animation-name: bounceInUp;">
                                    <table class="table table-bordered no-border font-13px margin-bottom-none">
                                        <thead>
                                            <tr>
                                                <td colspan="2"><strong>Service Department</strong></td>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>Mon:</td>
                                                <td>8:00am - 5:00pm</td>
                                            </tr>
                                            <tr>
                                                <td>Tue:</td>
                                                <td>8:00am - 9:00pm</td>
                                            </tr>
                                            <tr>
                                                <td>Wed:</td>
                                                <td>8:00am - 5:00pm</td>
                                            </tr>
                                            <tr>
                                                <td>Thu:</td>
                                                <td>8:00am - 9:00pm</td>
                                            </tr>
                                            <tr>
                                                <td>Fri:</td>
                                                <td>8:00am - 6:00pm</td>
                                            </tr>
                                            <tr>
                                                <td>Sat:</td>
                                                <td>9:00am - 5:00pm</td>
                                            </tr>
                                            <tr>
                                                <td>Sun:</td>
                                                <td>Closed</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-6 col-xs-12 xs-margin-bottom-40 sm-margin-bottom-none scroll_effect bounceInRight animated" data-wow-delay=".2s" style="visibility: visible; animation-delay: 0.2s; animation-name: bounceInRight;">
                        <div class="small-block clearfix">
                            <h4 class="margin-bottom-25 margin-top-none">About Us.</h4>
                            <a href="https://demo.themesuite.com/automotive/#"><span class="align-center"><i class="fa fa-users fa-7x"></i></span></a> </div>
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-6 col-xs-12 xs-margin-bottom-40 sm-margin-bottom-none padding-right-none scroll_effect bounceInRight animated" style="visibility: visible; animation-name: bounceInRight;">
                        <div class="small-block clearfix">
                            <h4 class="margin-bottom-25 margin-top-none">Find Us.</h4>
                            <a href="https://demo.themesuite.com/automotive/#"><span class="align-center"><i class="fa fa-map-marker fa-7x"></i></span></a> </div>
                    </div>
                </div>
            </section>
            <!--welcome-wrap ends-->
            
            <div class="row parallax_parent margin-top-30" style="height: 278px;">
                <div class="parallax_scroll clearfix" data-velocity="-.5" data-offset="-300" data-no-repeat="true" data-image="themes/automovile/images/parallax2.jpg" style="background-image: url(&quot;themes/automovile/images/parallax2.jpg&quot;); background-position: 50% -316px;">
                    <div class="overlay">
                        <div class="container">
                            
                            <div class="row">
                                
                                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 padding-left-none margin-vertical-60">
                                    <i class="fa fa-car"></i>
                                    
                                    <span class="animate_number margin-vertical-15">
                                        <span class="number">2,000</span>
                                    </span>
                                    
                                    Cars Sold
                                </div>
                                
                                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 margin-vertical-60">
                                    <i class="fa fa-money"></i>
                                    
                                    <span class="animate_number margin-vertical-15">
                                        $<span class="number">750,000</span>
                                    </span>
                                    
                                    Amount Sold
                                </div>
                                
                                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 margin-vertical-60">
                                    <i class="fa fa-users"></i>
                                    
                                    <span class="animate_number margin-vertical-15">
                                        <span class="number">100</span>%
                                    </span>
                                    
                                    Customer Satisfaction
                                </div>
                                
                                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 padding-right-none margin-vertical-60">
                                    <i class="fa fa-tint"></i>
                                    
                                    <span class="animate_number margin-vertical-15">
                                        <span class="number">3,600</span>
                                    </span>
                                    
                                    Oil Changes
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>